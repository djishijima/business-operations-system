"use client"

import { TemplateManager } from "@/components/admin/template-manager"

export default function TemplatesPage() {
  return (
    <div className="p-6">
      <TemplateManager />
    </div>
  )
}
